# NEXA MUSIC Website APK wrapper

Android wrapper that opens the live NEXA MUSIC website at https://davidtv4.github.io/nexa-music/.

- The APK needs an internet connection to display the live website.
- It is not a native player and does not add a backend or cloud sync.
- Browser-local data is separate from Chrome's data and other APK installs.
- The file chooser is enabled for importing audio files within the site.
- Build with JDK 17, Gradle 8.11.1 and Android SDK platform/build-tools 35.
- GitHub Actions produces a debug-signed test APK; it is not a Play Store release.
